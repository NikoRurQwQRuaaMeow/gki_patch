#!/bin/bash

TARGET_FILE="Makefile"
SEARCH_PATTERN="^NAME = .*"
KBUILD_LINE="KBUILD_CFLAGS   += -DKERNEL_\$(VERSION)_\$(PATCHLEVEL)"

if [ ! -f "${TARGET_FILE}" ]; then
  echo -e "错误: ${TARGET_FILE} 未找到! 请确保您在安卓内核源码的根目录下运行此脚本! "
  exit 1
fi

if ! grep -q -E "${SEARCH_PATTERN}" "${TARGET_FILE}"; then
  echo -e "错误: 在 ${TARGET_FILE} 中未找到锚点行 'NAME = ...'。文件可能已损坏或不是标准的内核Makefile。"
  exit 1
fi

if grep -q "DKERNEL_\$(VERSION)_\$(PATCHLEVEL)" "${TARGET_FILE}"; then
  echo -e "检测到定义已存在，无需重复修改! "
  exit 0
fi

sed -i.bak "s|${SEARCH_PATTERN}|&\n\n${KBUILD_LINE}|" "${TARGET_FILE}"
if [ $? -ne 0 ]; then
    echo -e "错误: sed 命令执行失败！文件未被修改！"
    exit 1
fi

if grep -q "DKERNEL_\$(VERSION)_\$(PATCHLEVEL)" "${TARGET_FILE}"; then
  echo -e "验证成功！KBUILD_CFLAGS 定义已成功写入 ${TARGET_FILE}！"
  echo "创建了备份文件 ${TARGET_FILE}.bak"
  exit 0
else
  echo -e "错误: 修改失败！验证时未在文件中找到新添加的行。"
  echo -e "请检查 ${TARGET_FILE} 的文件权限。原始文件已备份为 ${TARGET_FILE}.bak，您可以手动恢复。"
  exit 1
fi
